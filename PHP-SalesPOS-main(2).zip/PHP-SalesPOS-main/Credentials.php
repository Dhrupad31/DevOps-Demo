<?php

    $user = 'root';
    $password = 'root';
    $db = 'login';
    $host = 'localhost';
    $port = 3306;
?>